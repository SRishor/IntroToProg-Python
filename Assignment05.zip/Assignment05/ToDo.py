# --------------------------------------------------- #
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   SRishor, 11/19/2018, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# --------------------------------------------------- #

# --------------------- Data ------------------------ #
# declare variables and constants
strTask = ()
strPriority = ()
# objFile = An object that represents a file
objFileName = "ToDo.txt"
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dlcRow = {}
# lstTable = A dictionary that acts as a 'table' of rows
lstTable = []
# strMenu = A menu of user options
strMenu = ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program")
    """)
# strChoice = Capture the user option selection
strChoice = ()
# --------------------------------------------------- #


# ------------------ Input/Output --------------------#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)
# --------------------------------------------------- #

# -------------------- Processing ------------------- #
# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"

objFile = open(objFileName,"r")
for line in objFile:
    strTask = line.split(",")[0]
    strPriority = line.split(",")[1]
    # Removing the '\n' character
    strPriority = strPriority[:-1]
    dicRow = {"Task": strTask, "Priority": strPriority}
    lstTable.append(dicRow)
objFile.close()

# Step 2 - Display a menu of choices to the user
while (True):
    print(strMenu)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):

        # Print the data that is currently in the table
        print("********** The current items to complete are: **********")
        for item in lstTable:
            print(item["Task"] + " (" + item["Priority"] + ")")
        print("******************* Good Luck **************************\n")

        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):

        # Ask the user what task(s) they would like to add:
        strTaskAdd = input("Please enter a new task: ").capitalize()
        strPriorityAdd = input("Please state the priority (high/low): ").capitalize()
        # Append new input to the dictionary:
        dicRowNew = {"Task":strTaskAdd,"Priority":strPriorityAdd}
        lstTable.append(dicRowNew)
        # Display the new list to the user:
        print("\n********** The current items to complete are: **********")
        for item in lstTable:
            print(item["Task"] + " (" + item["Priority"] + ")")
        print("******************* Good Luck **************************\n")

        continue


    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):

        # Ask the user what task(s) they would like to remove:
        strTaskRemove = str(input("Please enter a new task to remove: "))
        # Verifying item exists in dictionary:
        # Initializing variables:
        blnTask = False
        intItem = 0
        # For tasks found in dictionary:
        for item in lstTable:
            if strTaskRemove == item["Task"]:
                del lstTable[intItem]
                blnTask = True
            else:
                intItem = intItem + 1
        # Displaying updated list with task removed:
        if blnTask == True:
            print("The task has been deleted.")
            print("\n********** The current items to complete are: **********")
            for item in lstTable:
                print(item["Task"] + " (" + item["Priority"] + ")")
            print("******************* Good Luck **************************\n")
        # For tasks not found in dictionary:
        else:
            print("Task not found. Please try again.\n")

            continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):

        objFile = open(objFileName,"w")
        for item in lstTable:
            objFile.write(item["Task"] + "," + item["Priority"] + "\n")
        print("List has been saved!")

        continue

    # Step 7 - Exit the program
    elif (strChoice == '5'):

        objFile.close()
        break  # and Exit the program
# --------------------------------------------------- #



