# --------------------------------------------------- #
# Title: Working with Functions
# Dev:   SRishor
# Date:  24 November 2018
# ChangeLog: (Who, When, What)
#   SRishor, 24NOV2018, Created starting template
# --------------------------------------------------- #

'''
Objective:
Now that you have reviewed the websites and videos, you will create a new script
that manages a "ToDo list." This project is like to the last one, but different
enough to be a challenge. This project is very like the last one, but this time
you will place the code you created for working with your ToDo.txt file into
Functions and a Class.
'''

# --------------------- Data ------------------------ #
# declare variables and constants
strTask = ()
strPriority = ()
# objFile = An object that represents a file
objFileName = "ToDo.txt"
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dlcRow = {}
# lstTable = A dictionary that acts as a 'table' of rows
lstTable = []
# strMenu = A menu of user options
strMenu = ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program")
    """)
# strChoice = Capture the user option selection
strChoice = ()
# --------------------------------------------------- #


# ------------------ Input/Output --------------------#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)
# --------------------------------------------------- #

# -------------------- Processing ------------------- #
# Creating a class which will include all the data processing functions
class ProcessData(object):

    # Step 1 - Load data from a file
        # When the program starts, load each "row" of data
        # in "ToDo.txt" into a python Dictionary.
        # Add the each dictionary "row" to a python list "table"
    @staticmethod
    def LoadData(objFileName):
        objFile = open(objFileName, "r")
        for line in objFile:
            strTask = line.split(",")[0]
            strPriority = line.split(",")[1]
            # Removing the '\n' character
            strPriority = strPriority[:-1]
            dicRow = {"Task": strTask, "Priority": strPriority}
            lstTable.append(dicRow)
        objFile.close()


    # Step 3 -Show the current items in the table
    @staticmethod
    def ShowData(lst):
        # Print the data that is currently in the table
        print("********** The current items to complete are: **********")
        for item in lstTable:
            print(item["Task"] + " (" + item["Priority"] + ")")
        print("******************* Good Luck **************************\n")


    # Step 4 - Add a new item to the list/Table
    @staticmethod
    def AddData(strTask, strPriority):
        dicRowNew = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRowNew)


    # Step 5 - Remove a new item to the list/Table
    @staticmethod
    def RemoveData(strRemoveTask):
        # Verifying item exists in dictionary:
        # Initializing variables:
        blnTask = False
        intItem = 0
        for item in lstTable:
            if strRemoveTask == item["Task"]:
                del lstTable[intItem]
                blnTask = True
            else:
                intItem = intItem + 1
        return blnTask

    # Step 6 - Save tasks to the ToDo.txt file
    @staticmethod
    def SaveData(objFileName):
        objFile = open(objFileName, "w")
        for item in lstTable:
            objFile.write(item["Task"] + "," + item["Priority"] + "\n")
        objFile.close()
# --------------------------------------------------- #


# ------------------- Presentation ------------------ #

# Step 1 - Load data from a file
ProcessData.LoadData(objFileName)

# Step 2 - Display a menu of choices to the user
while(True):
    print(strMenu)
    strChoice = str(input("Which option would you like to perform? "))

    # Step 3: Display the data currently in ToDo.txt
    if(strChoice.strip() == "1"):
        ProcessData.ShowData(lstTable)
        continue

    # Step 4: Adding a new item to the list
    elif(strChoice.strip() == "2"):
        # Ask the user what task(s) they would like to add:
        strTaskAdd = input("Please enter a new task: ").capitalize()
        strPriorityAdd = input("Please state the priority (high/low): ").capitalize()
        ProcessData.AddData(strTaskAdd, strPriorityAdd)
        # Display the new list to the user:
        print("\n********** The current items to complete are: **********")
        for item in lstTable:
            print(item["Task"] + " (" + item["Priority"] + ")")
        print("******************* Good Luck **************************\n")
        continue

    # Step 5: Removing an existing item from the list
    elif(strChoice.strip() == "3"):
        strTaskRemove = str(input("Please enter a task to remove: "))
        if ProcessData.RemoveData(strTaskRemove) == True:
            print("The task has been deleted.")
            print("\n********** The current items to complete are: **********")
            for item in lstTable:
                print(item["Task"] + " (" + item["Priority"] + ")")
            print("******************* Good Luck **************************\n")
        # For tasks not found in dictionary:
        else:
            print("Task not found. Please try again.\n")
        continue

    # Step 6: Save the new information to the file
    elif(strChoice.strip() == "4"):
        ProcessData.SaveData(objFileName)
        print("List has been saved!")
        continue

    # Step 7: Close the program
    elif(strChoice.strip() == "5"):
        break

    else:
        print("Please choose from options 1-5.")
        continue